﻿/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"] ,
  theme: {
    extend: {
      fontFamily: {
        display: ["'Bebas Neue'", "sans-serif"],
        body: ["'Sora'", "sans-serif"],
      },
      boxShadow: {
        glow: "0 0 30px rgba(251, 191, 36, 0.35)",
      },
    },
  },
  plugins: [],
};
