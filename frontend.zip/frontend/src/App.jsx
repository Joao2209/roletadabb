import { useEffect, useMemo, useState } from "react";
import pointerImg from "../img/roleta_topo_1773089780_69af33f4237b6.webp";
import bgImg from "../img/foto de fundo/Captura de tela 2026-03-18 143344.png";
import premio1 from "../img/premios/premio-1.png";
import premio2 from "../img/premios/premio-2.png";
import premio3 from "../img/premios/premio-3.png";
import premio4 from "../img/premios/premio-4.png";
import premio5 from "../img/premios/premio-5.png";
import premio6 from "../img/premios/premio-6.png";
import premio7 from "../img/premios/premio-7.png";
import premio8 from "../img/premios/premio-8.png";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:4000";

const fetchJson = async (url, options = {}) => {
  const res = await fetch(url, {
    cache: "no-store",
    ...options,
    headers: {
      "Content-Type": "application/json",
      "Cache-Control": "no-cache",
      ...(options.headers || {}),
    },
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || "Erro" );
  }
  return data;
};

const getStoredUserId = () => localStorage.getItem("roleta_user_id");

export default function App() {
  const [userId, setUserId] = useState(getStoredUserId());
  const [balance, setBalance] = useState(0);
  const [spinCost, setSpinCost] = useState(0);
  const [rewards, setRewards] = useState([]);
  const [rotation, setRotation] = useState(0);
  const [isSpinning, setIsSpinning] = useState(false);
  const [result, setResult] = useState(null);
  const [depositOpen, setDepositOpen] = useState(false);
  const [depositAmount, setDepositAmount] = useState(10);
  const [pixData, setPixData] = useState(null);
  const [showWin, setShowWin] = useState(false);
  const [winImage, setWinImage] = useState(null);
  const [winLabel, setWinLabel] = useState("");
  const [customerName, setCustomerName] = useState("Visitante");
  const [customerEmail, setCustomerEmail] = useState("");
  const [customerCpf, setCustomerCpf] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const spinCostDisplay = 2;

  const rewardImages = [
    premio1,
    premio2,
    premio3,
    premio4,
    premio5,
    premio6,
    premio7,
    premio8,
  ];

  const wheelItems = rewards.length
    ? rewards.map((reward, idx) => ({
        id: reward.id,
        label: reward.label,
        img: rewardImages[idx % rewardImages.length],
      }))
    : rewardImages.map((img, idx) => ({
        id: `placeholder-${idx}`,
        label: `Premio ${idx + 1}`,
        img,
      }));

  useEffect(() => {
    const init = async () => {
      let id = userId;
      if (!id) {
        const data = await fetchJson(`${API_URL}/api/users`, {
          method: "POST",
          body: JSON.stringify({ name: "Visitante" }),
        });
        id = data.userId;
        localStorage.setItem("roleta_user_id", id);
        setUserId(id);
      }
    };
    init().catch(console.error);
  }, [userId]);

  useEffect(() => {
    if (!userId) return;
    const load = async () => {
      const [userRes, rewardsRes, configRes] = await Promise.all([
        fetchJson(`${API_URL}/api/users/me`, { headers: { "x-user-id": userId } }),
        fetchJson(`${API_URL}/api/rewards`),
        fetchJson(`${API_URL}/api/spin/config`, { headers: { "x-user-id": userId } }),
      ]);
      setBalance(userRes.user.balance);
      setRewards(rewardsRes.rewards);
      setSpinCost(configRes.spinCost);
    };
    load().catch(console.error);
  }, [userId]);

  const segments = useMemo(() => wheelItems.length || 1, [wheelItems]);
  const segmentAngle = useMemo(() => 360 / segments, [segments]);
  const wheelStyle = useMemo(() => {
    const fallbackColors = ["#4c1d1d", "#5b1f1f", "#3b0f0f", "#5f1a1a"];
    if (!segments) {
      return { background: "conic-gradient(#1e293b 0deg, #0f172a 360deg)" };
    }
    const gradientStops = Array.from({ length: segments }).map((_, idx) => {
      const start = idx * segmentAngle;
      const end = start + segmentAngle;
      const color = rewards.length
        ? rewards[idx % rewards.length]?.color || fallbackColors[idx % fallbackColors.length]
        : fallbackColors[idx % fallbackColors.length];
      return `${color} ${start}deg ${end}deg`;
    });
    return {
      backgroundImage: `conic-gradient(${gradientStops.join(",")}), repeating-conic-gradient(from 0deg, transparent 0deg, transparent calc(${segmentAngle}deg - 2deg), rgba(255, 215, 128, 0.9) calc(${segmentAngle}deg - 2deg), rgba(255, 215, 128, 0.9) ${segmentAngle}deg)`,
    };
  }, [segments, segmentAngle, rewards, wheelItems]);

  const sliceClip = (startDeg, endDeg) => {
    const toPoint = (deg) => {
      const rad = ((deg - 90) * Math.PI) / 180;
      const x = 50 + 50 * Math.cos(rad);
      const y = 50 + 50 * Math.sin(rad);
      return `${x}% ${y}%`;
    };
    return `polygon(50% 50%, ${toPoint(startDeg)}, ${toPoint(endDeg)})`;
  };

  const sliceBgPosition = (midDeg) => {
    const rad = ((midDeg - 90) * Math.PI) / 180;
    const x = 50 + 22 * Math.cos(rad);
    const y = 50 + 22 * Math.sin(rad);
    return `${x}% ${y}%`;
  };

  const handleSpin = async () => {
    if (isSpinning) return;
    setIsSpinning(true);
    setResult(null);
    setShowWin(false);
    try {
      const data = await fetchJson(`${API_URL}/api/spin`, {
        method: "POST",
        headers: { "x-user-id": userId },
      });

      const newRotation = rotation + data.rotationDegrees;
      setRotation(newRotation);
      setBalance(data.balance);
      setTimeout(() => {
        setResult(data.reward);
        setIsSpinning(false);
        const rewardIndex =
          rewards.findIndex((r) => r.id === data.reward.id) >= 0
            ? rewards.findIndex((r) => r.id === data.reward.id)
            : 0;
        const img = rewardImages[rewardIndex % rewardImages.length];
        setWinImage(img);
        setWinLabel(data.reward.label || "Prêmio");
        setShowWin(true);
      }, 4200);
    } catch (err) {
      setIsSpinning(false);
      alert(err.message);
    }
  };

  const handleDeposit = async () => {
    try {
      const data = await fetchJson(`${API_URL}/api/payments/deposit`, {
        method: "POST",
        headers: { "x-user-id": userId },
        body: JSON.stringify({
          amount: Number(depositAmount),
          customer: {
            name: customerName,
            email: customerEmail,
            document: customerCpf,
            phone: customerPhone,
          },
        }),
      });
      setPixData(data);
    } catch (err) {
      alert(err.message);
    }
  };

  const bonusMap = {
    10: 0,
    30: 10,
    50: 30,
    100: 50,
  };
  const bonusValue = bonusMap[depositAmount] ?? 0;

  

  return (
    <div className="min-h-screen app-bg text-white" style={{ backgroundImage: `url(${bgImg})` }}>
      <div className="min-h-screen app-overlay">
        <div className="mx-auto max-w-[520px] px-4 py-6">
          <section className="hero-cover relative overflow-hidden rounded-3xl border border-red-500/30">
            <div className="h-[200px] md:h-[260px]"></div>
          </section>

          <div className="flex items-center justify-center">
            <div className="text-center">
              <p className="text-xs uppercase tracking-[0.5em] text-amber-200">Roleta Premium</p>
            </div>
          </div>

          <div className="fixed right-4 top-24 flex flex-col gap-3">
            <button className="floating-btn h-12 w-12 rounded-full text-xs font-semibold uppercase">Perfil</button>
            <button className="floating-btn h-12 w-12 rounded-full text-xs font-semibold uppercase">Som</button>
          </div>

          <div className="mt-6 grid grid-cols-4 items-center gap-3">
            <button
              className="bottom-pill col-span-1 rounded-2xl px-4 py-3 text-sm font-semibold text-white"
              onClick={() => {
                setDepositOpen(true);
                setPixData(null);
              }}
            >
              Depositar
            </button>
            <button
              className="bottom-pill col-span-1 rounded-2xl px-4 py-3 text-sm font-semibold text-white"
              onClick={async () => {
                const key = window.prompt("Admin key:");
                if (!key) return;
                try {
                  const data = await fetchJson(`${API_URL}/api/users/me/credit-test`, {
                    method: "POST",
                    headers: { "x-user-id": userId, "x-admin-key": key },
                    body: JSON.stringify({ amount: 10 }),
                  });
                  setBalance(data.balance);
                  alert("Crédito adicionado!");
                } catch (err) {
                  alert(err.message);
                }
              }}
            >
              Admin
            </button>
            <div className="bottom-pill col-span-1 rounded-2xl px-4 py-3 text-center">
              <p className="text-xs text-amber-200">Saldo</p>
              <p className="text-lg font-semibold">R$ {balance.toFixed(2)}</p>
            </div>
            <div className="bottom-pill col-span-1 rounded-2xl px-4 py-3 text-center">
              <p className="text-xs text-amber-200">Giro</p>
              <p className="text-lg font-semibold">R$ {spinCostDisplay.toFixed(2)}</p>
            </div>
          </div>

          <div className="mt-16 flex flex-col items-center">
            <div className="relative">
              <img
                src={pointerImg}
                alt="Seta da roleta"
                className="absolute -top-20 left-1/2 -translate-x-1/2 w-[320px] max-w-none z-20"
              />
              <div className="wheel-frame">
                <div
                  className="wheel-inner relative overflow-visible h-[320px] w-[320px] md:h-[360px] md:w-[360px] z-10"
                  style={{
                    ...wheelStyle,
                    transform: `rotate(${rotation}deg)`,
                    transition: isSpinning ? "transform 4.2s cubic-bezier(0.17, 0.67, 0.2, 0.99)" : "none",
                  }}
                >
                  {wheelItems.map((item, idx) => {
                    const start = idx * segmentAngle;
                    const end = start + segmentAngle;
                    const mid = start + segmentAngle / 2;
                    return (
                      <div key={item.id}>
                        <div
                          className="wheel-slice"
                          style={{
                            clipPath: sliceClip(start, end),
                            backgroundImage: `linear-gradient(180deg, rgba(0,0,0,0.15) 0%, rgba(0,0,0,0.45) 80%), url(${item.img})`,
                            backgroundPosition: sliceBgPosition(mid),
                          }}
                          title={item.label}
                        ></div>
                        <div
                          className="reward-text"
                          style={{
                            transform: `rotate(${mid}deg) translate(0, -145px) rotate(90deg)`,
                          }}
                        >
                          {item.label}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
              <div className="absolute inset-0 m-auto h-16 w-16 rounded-full bg-gradient-to-b from-amber-200 to-amber-600 border-2 border-amber-300 shadow-xl"></div>
            </div>

            {result && (
              <div className="mt-4 rounded-full bg-black/60 px-4 py-2 text-sm">
                Resultado: {result.label}
              </div>
            )}
          </div>

          <div className="mt-6 flex items-center justify-center">
            <button
              className="spin-lip rounded-full px-8 py-3 text-lg font-semibold uppercase"
              onClick={handleSpin}
              disabled={isSpinning}
            >
              {isSpinning ? "Girando..." : "Girar sua roleta"}
            </button>
          </div>

          <div className="mt-5 grid grid-cols-2 gap-4">
            {wheelItems.map((item, idx) => (
              <div
                key={`list-${item.id}`}
                className="rounded-xl bg-black/50 p-2 text-center text-xs"
              >
                <div className="text-amber-200 font-semibold">#{idx + 1}</div>
                <img
                  src={item.img}
                  alt={item.label}
                  className="mx-auto mt-2 h-40 w-40 rounded-lg object-cover"
                />
                <div className="mt-2 text-sm text-amber-100">{item.label}</div>
              </div>
            ))}
          </div>

        </div>
      </div>

      {depositOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 px-6">
          <div className="w-full max-w-md rounded-2xl bg-slate-900 p-6">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-semibold">Depositar via PIX</h3>
              <button onClick={() => setDepositOpen(false)} className="text-slate-400">
                Fechar
              </button>
            </div>
            <div className="mt-4">
              <label className="text-sm text-slate-400">Nome</label>
              <input
                className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
              />
              <label className="mt-3 text-sm text-slate-400">E-mail</label>
              <input
                className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2"
                type="email"
                value={customerEmail}
                onChange={(e) => setCustomerEmail(e.target.value)}
              />
              <label className="mt-3 text-sm text-slate-400">CPF</label>
              <input
                className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2"
                value={customerCpf}
                onChange={(e) => setCustomerCpf(e.target.value)}
              />
              <label className="mt-3 text-sm text-slate-400">Telefone</label>
              <input
                className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2"
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
              />
              <label className="text-sm text-slate-400">Escolha o valor</label>
              <div className="mt-2 grid grid-cols-2 gap-3">
                {[10, 30, 50, 100].map((value) => (
                  <button
                    key={value}
                    className={`rounded-xl px-3 py-3 text-sm font-semibold ${
                      depositAmount === value
                        ? "bg-amber-400 text-slate-900"
                        : "bg-slate-800 text-slate-100"
                    }`}
                    onClick={() => setDepositAmount(value)}
                  >
                    R$ {value} {bonusMap[value] ? `+ R$ ${bonusMap[value]} bônus` : ""}
                  </button>
                ))}
              </div>
              <div className="mt-3 text-xs text-amber-200">
                Bônus: R$ {bonusValue.toFixed(2)} | Total: R$ {(Number(depositAmount) + bonusValue).toFixed(2)}
              </div>
              <button
                className="mt-4 w-full rounded-xl bg-amber-400 px-4 py-2 text-slate-900"
                onClick={handleDeposit}
              >
                Gerar QR Code
              </button>
            </div>
            {pixData && (
              <div className="mt-6 rounded-xl bg-slate-800/70 p-4 text-center">
                <p className="text-sm text-amber-300">Escaneie o QR code</p>
                {pixData.qrCode ? (
                  <img src={pixData.qrCode} alt="PIX" className="mx-auto mt-3 h-40 w-40" />
                ) : (
                  <div className="mt-3 text-xs text-slate-400">QR code não retornado pela API.</div>
                )}
                {pixData.qrCodeText && (
                  <div className="mt-3">
                    <textarea
                      className="w-full rounded-lg bg-slate-900/80 p-2 text-xs"
                      rows={3}
                      readOnly
                      value={pixData.qrCodeText}
                    />
                    <button
                      className="mt-2 w-full rounded-lg bg-amber-400 px-3 py-2 text-sm font-semibold text-slate-900"
                      onClick={async () => {
                        try {
                          await navigator.clipboard.writeText(pixData.qrCodeText);
                          alert("Código PIX copiado!");
                        } catch (err) {
                          alert("Não foi possível copiar.");
                        }
                      }}
                    >
                      Copiar código PIX
                    </button>
                  </div>
                )}
                {pixData.raw && (
                  <pre className="mt-3 max-h-40 overflow-auto rounded-lg bg-black/60 p-2 text-left text-[10px] text-amber-100">
                    {JSON.stringify(pixData.raw, null, 2)}
                  </pre>
                )}
                <p className="mt-2 text-xs text-slate-400">
                  O saldo será atualizado após a confirmação do pagamento.
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {showWin && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 px-6">
          <div className="confetti">
            {Array.from({ length: 24 }).map((_, i) => (
              <span key={i} style={{ "--i": i }}></span>
            ))}
          </div>
          <div className="win-card">
            <p className="text-sm uppercase tracking-[0.3em] text-amber-200">Parabéns!</p>
            <h3 className="mt-2 text-2xl font-semibold">{winLabel}</h3>
            {winImage && <img src={winImage} alt={winLabel} className="mt-4 h-48 w-48 rounded-xl object-cover" />}
            <button
              className="mt-4 w-full rounded-lg bg-amber-400 px-4 py-2 text-slate-900 font-semibold"
              onClick={() => setShowWin(false)}
            >
              Fechar
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
