﻿import { Router } from "express";
import { createUser, getMe, getHistory, creditTest } from "../controllers/userController.js";
import { requireUser, requireAdmin } from "../services/authService.js";

const router = Router();

router.post("/", createUser);
router.get("/me", requireUser, getMe);
router.get("/me/history", requireUser, getHistory);
router.post("/me/credit-test", requireUser, requireAdmin, creditTest);

export default router;
