﻿import { Router } from "express";
import {
  getDashboard,
  listRewardsAdmin,
  createReward,
  updateReward,
  updateSpinCost,
} from "../controllers/adminController.js";
import { requireAdmin } from "../services/authService.js";

const router = Router();

router.use(requireAdmin);

router.get("/dashboard", getDashboard);
router.get("/rewards", listRewardsAdmin);
router.post("/rewards", createReward);
router.put("/rewards/:id", updateReward);
router.put("/spin-cost", updateSpinCost);

export default router;
