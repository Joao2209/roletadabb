﻿import { Router } from "express";
import { createDeposit, syncPayWebhook } from "../controllers/paymentController.js";
import { requireUser } from "../services/authService.js";

const router = Router();

router.post("/deposit", requireUser, createDeposit);
router.post("/syncpay/webhook", syncPayWebhook);

export default router;
