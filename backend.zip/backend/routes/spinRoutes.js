﻿import { Router } from "express";
import { spinWheel, getSpinConfig } from "../controllers/spinController.js";
import { requireUser } from "../services/authService.js";

const router = Router();

router.get("/config", requireUser, getSpinConfig);
router.post("/", requireUser, spinWheel);

export default router;
