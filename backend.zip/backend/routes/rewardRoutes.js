﻿import { Router } from "express";
import { listRewards } from "../controllers/rewardController.js";

const router = Router();

router.get("/", listRewards);

export default router;
