﻿import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import morgan from "morgan";
import dotenv from "dotenv";
import mongoose from "mongoose";

import userRoutes from "./routes/userRoutes.js";
import spinRoutes from "./routes/spinRoutes.js";
import rewardRoutes from "./routes/rewardRoutes.js";
import paymentRoutes from "./routes/paymentRoutes.js";
import adminRoutes from "./routes/adminRoutes.js";

import { errorHandler, notFoundHandler } from "./services/errorService.js";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 4000;

app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN || "*" }));
app.use(express.json({ limit: "1mb" }));
app.use(morgan("dev"));

app.use(
  rateLimit({
    windowMs: 60 * 1000,
    max: 120,
    standardHeaders: true,
    legacyHeaders: false,
  })
);

app.get("/health", (req, res) => {
  res.json({ status: "ok" });
});

app.use("/api/users", userRoutes);
app.use("/api/spin", spinRoutes);
app.use("/api/rewards", rewardRoutes);
app.use("/api/payments", paymentRoutes);
app.use("/api/admin", adminRoutes);

app.use(notFoundHandler);
app.use(errorHandler);

const start = async () => {
  const useDb = process.env.NO_DB !== "1";
  if (useDb) {
    const mongoUri = process.env.MONGODB_URI;
    if (!mongoUri) {
      throw new Error("MONGODB_URI is not set");
    }
    await mongoose.connect(mongoUri);
  }
  app.listen(PORT, () => {
    console.log(`Roleta Premium API running on port ${PORT}${useDb ? "" : " (NO_DB)"}`);
  });
};

start().catch((err) => {
  console.error(err);
  process.exit(1);
});
