﻿import dotenv from "dotenv";
import mongoose from "mongoose";
import Reward from "../models/Reward.js";
import Settings from "../models/Settings.js";
import User from "../models/User.js";

dotenv.config();

const seed = async () => {
  await mongoose.connect(process.env.MONGODB_URI);

  await Reward.deleteMany({});
  await Settings.deleteMany({});

  await Reward.insertMany([
    { label: "Prêmio 1", weight: 35, type: "content", order: 1, color: "#f97316" },
    { label: "Prêmio 2", weight: 25, type: "content", order: 2, color: "#22c55e" },
    { label: "Prêmio 3", weight: 18, type: "access", order: 3, color: "#3b82f6" },
    { label: "Prêmio 4", weight: 2, type: "special", order: 4, color: "#e11d48" },
    { label: "Prêmio 5", weight: 2, type: "special", order: 5, color: "#a855f7" },
    { label: "Prêmio 6", weight: 10, type: "content", order: 6, color: "#f59e0b" },
    { label: "Prêmio 7", weight: 6, type: "content", order: 7, color: "#14b8a6" },
    { label: "Prêmio 8", weight: 2, type: "special", order: 8, color: "#ef4444" },
  ]);

  await Settings.create({ key: "spin_cost", value: 2 });

  const demoUser = await User.create({ name: "Demo", email: "demo@roleta.local", balance: 20 });

  console.log("Seeded rewards and settings.");
  console.log(`Demo user id: ${demoUser.id}`);

  await mongoose.disconnect();
};

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});
