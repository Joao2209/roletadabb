import Payment from "../models/Payment.js";
import Transaction from "../models/Transaction.js";
import { createPixCharge, verifyWebhookSignature } from "../services/paymentService.js";
import { memory } from "../services/memoryStore.js";

const useDb = process.env.NO_DB !== "1";

export const createDeposit = async (req, res, next) => {
  try {
    const { amount, customer } = req.body || {};
    const baseAmount = Number(amount);
    if (!baseAmount || baseAmount <= 0) {
      return res.status(400).json({ error: "Valor inválido" });
    }
    if (!customer || !customer.name || !customer.email || !customer.document || !customer.phone) {
      return res.status(400).json({ error: "Dados do cliente são obrigatórios" });
    }

    const bonusTable = {
      10: 0,
      30: 10,
      50: 30,
      100: 50,
    };
    const bonus = bonusTable[baseAmount] ?? 0;

    const externalId = `user_${req.user.id}_${Date.now()}`;
    const charge = await createPixCharge({
      amount: baseAmount,
      description: "Roleta Premium recarga",
      externalId,
      ip: req.ip,
      customer,
    });

    const pick = (obj, paths) => {
      for (const path of paths) {
        const value = path.split(".").reduce((acc, key) => (acc ? acc[key] : undefined), obj);
        if (value) return value;
      }
      return undefined;
    };

    const providerId =
      pick(charge, ["idTransaction", "id", "provider_id", "data.idTransaction", "data.id"]) || externalId;
    const qrBase64 =
      pick(charge, ["paymentCodeBase64", "qrCodeBase64", "data.paymentCodeBase64", "data.qrCodeBase64"]) || null;
    const qrText =
      pick(charge, ["paymentCode", "qrCodeText", "data.paymentCode", "data.qrCodeText", "emv", "pix_code"]) || null;

    let qrCodeDataUrl = qrBase64 ? `data:image/png;base64,${qrBase64}` : null;
    if (!qrCodeDataUrl && qrText) {
      try {
        const QRCode = (await import("qrcode")).default;
        qrCodeDataUrl = await QRCode.toDataURL(qrText);
      } catch {
        qrCodeDataUrl = null;
      }
    }

    const payment = useDb
      ? await Payment.create({
          userId: req.user.id,
          providerId,
          amount: baseAmount,
          bonus,
          status: "pending",
          qrCode: qrCodeDataUrl || pick(charge, ["qr_code", "qrCode", "qrCodeImage"]),
          qrCodeText: qrText,
          raw: charge,
        })
      : (() => {
          const p = {
            id: providerId,
            userId: req.user.id,
            providerId,
            amount: baseAmount,
            bonus,
            status: "pending",
            qrCode: qrCodeDataUrl || pick(charge, ["qr_code", "qrCode", "qrCodeImage"]),
            qrCodeText: qrText,
            raw: charge,
          };
          memory.savePayment(p);
          return p;
        })();

    res.status(201).json({
      paymentId: payment.id || payment.providerId,
      providerId,
      amount: baseAmount,
      bonus,
      totalCredit: baseAmount + bonus,
      qrCode: payment.qrCode,
      qrCodeText: payment.qrCodeText,
      raw: payment.qrCode ? undefined : charge,
      debug: {
        baseUrl: process.env.SYNCPAY_BASE_URL,
        pixEndpoint: process.env.SYNCPAY_PIX_ENDPOINT,
      },
    });
  } catch (err) {
    if (err.message === "SYNCPAY_CONFIG_MISSING") {
      return res.status(500).json({ error: "Configuração Sync Pay ausente" });
    }
    next(err);
  }
};

export const syncPayWebhook = async (req, res, next) => {
  try {
    if (!verifyWebhookSignature(req)) {
      return res.status(401).json({ error: "Invalid signature" });
    }

    const payload = req.body || {};
    const providerId = payload.id || payload.charge_id || payload.provider_id;
    const externalId = payload.external_id;
    const status = payload.status;
    const amount = payload.amount;

    let payment = null;
    if (providerId) {
      payment = useDb ? await Payment.findOne({ providerId }) : memory.getPaymentByProviderId(providerId);
    }
    if (!payment && externalId) {
      payment = await Payment.findOne({ "raw.external_id": externalId });
    }

    if (!payment) {
      return res.status(404).json({ error: "Payment not found" });
    }

    if (payment.status === "confirmed") {
      return res.json({ ok: true });
    }

    if (status === "confirmed" || status === "paid") {
      payment.status = "confirmed";
      await payment.save();

      const user = req.user || null;
      if (!user) {
        if (useDb) {
          const User = (await import("../models/User.js")).default;
          const targetUser = await User.findById(payment.userId);
          if (targetUser) {
            const creditAmount = (amount || payment.amount) + (payment.bonus || 0);
            targetUser.balance += creditAmount;
            await targetUser.save();

            await Transaction.create({
              userId: targetUser.id,
              type: "credit",
              amount: creditAmount,
              reason: "pix_deposit",
              meta: { providerId: payment.providerId, bonus: payment.bonus || 0 },
            });
          }
        } else {
          const targetUser = memory.getUser(payment.userId);
          if (targetUser) {
            const creditAmount = (amount || payment.amount) + (payment.bonus || 0);
            targetUser.balance += creditAmount;
            memory.updateUser(targetUser);
            memory.addTransaction({
              userId: targetUser.id,
              type: "credit",
              amount: creditAmount,
              reason: "pix_deposit",
              meta: { providerId: payment.providerId, bonus: payment.bonus || 0 },
              createdAt: new Date().toISOString(),
            });
          }
        }
      }
    }

    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
};
