import User from "../models/User.js";
import Transaction from "../models/Transaction.js";
import Spin from "../models/Spin.js";
import { memory } from "../services/memoryStore.js";

const useDb = process.env.NO_DB !== "1";

export const createUser = async (req, res, next) => {
  try {
    const { name, email } = req.body || {};
    const user = useDb ? await User.create({ name, email }) : memory.createUser({ name, email });
    res.status(201).json({ userId: user.id, user });
  } catch (err) {
    next(err);
  }
};

export const getMe = async (req, res, next) => {
  try {
    res.json({ user: req.user });
  } catch (err) {
    next(err);
  }
};

export const getHistory = async (req, res, next) => {
  try {
    const transactions = useDb
      ? await Transaction.find({ userId: req.user.id }).sort({ createdAt: -1 }).limit(50)
      : memory.listTransactions(req.user.id);
    const spins = useDb
      ? await Spin.find({ userId: req.user.id }).sort({ createdAt: -1 }).limit(50)
      : memory.listSpins(req.user.id);

    res.json({ transactions, spins });
  } catch (err) {
    next(err);
  }
};

export const creditTest = async (req, res, next) => {
  try {
    const amount = Number(req.body?.amount ?? 10);
    if (!amount || amount <= 0) {
      return res.status(400).json({ error: "Valor inválido" });
    }

    req.user.balance += amount;
    if (useDb) {
      await req.user.save();
      await Transaction.create({
        userId: req.user.id,
        type: "credit",
        amount,
        reason: "admin_test_credit",
      });
    } else {
      memory.updateUser(req.user);
      memory.addTransaction({
        userId: req.user.id,
        type: "credit",
        amount,
        reason: "admin_test_credit",
        createdAt: new Date().toISOString(),
      });
    }

    res.json({ balance: req.user.balance });
  } catch (err) {
    next(err);
  }
};
