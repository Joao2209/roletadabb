﻿import { createSpin, getSpinCost } from "../services/spinService.js";

export const spinWheel = async (req, res, next) => {
  try {
    const { spin, reward, rewards, spinCost } = await createSpin({ user: req.user });

    res.json({
      spinId: spin.id,
      reward: {
        id: reward.id,
        label: reward.label,
        type: reward.type,
        value: reward.value,
      },
      rotationDegrees: spin.rotationDegrees,
      balance: req.user.balance,
      spinCost,
      rewards: rewards.map((r) => ({
        id: r.id,
        label: r.label,
        color: r.color,
        order: r.order,
      })),
    });
  } catch (err) {
    if (err.message === "INSUFFICIENT_BALANCE") {
      return res.status(400).json({ error: "Saldo insuficiente" });
    }
    if (err.message === "NO_REWARDS") {
      return res.status(400).json({ error: "Nenhuma recompensa ativa" });
    }
    next(err);
  }
};

export const getSpinConfig = async (req, res, next) => {
  try {
    const spinCost = await getSpinCost();
    res.json({ spinCost });
  } catch (err) {
    next(err);
  }
};
