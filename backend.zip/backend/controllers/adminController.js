import Reward from "../models/Reward.js";
import Spin from "../models/Spin.js";
import Transaction from "../models/Transaction.js";
import Settings from "../models/Settings.js";
import { memory } from "../services/memoryStore.js";

const useDb = process.env.NO_DB !== "1";

export const getDashboard = async (req, res, next) => {
  try {
    const spins = useDb ? await Spin.countDocuments() : memory.listSpins("").length;
    const totalEarnings = useDb
      ? (await Transaction.aggregate([
          { $match: { type: "credit", reason: "pix_deposit" } },
          { $group: { _id: null, total: { $sum: "$amount" } } },
        ]))?.[0]?.total || 0
      : memory.listTransactions("").reduce((acc, t) => acc + (t.amount || 0), 0);
    res.json({ spins, totalEarnings });
  } catch (err) {
    next(err);
  }
};

export const listRewardsAdmin = async (req, res, next) => {
  try {
    const rewards = useDb ? await Reward.find().sort({ order: 1 }) : memory.listRewards();
    res.json({ rewards });
  } catch (err) {
    next(err);
  }
};

export const createReward = async (req, res, next) => {
  try {
    const reward = useDb ? await Reward.create(req.body) : null;
    res.status(201).json({ reward });
  } catch (err) {
    next(err);
  }
};

export const updateReward = async (req, res, next) => {
  try {
    const reward = useDb ? await Reward.findByIdAndUpdate(req.params.id, req.body, { new: true }) : null;
    res.json({ reward });
  } catch (err) {
    next(err);
  }
};

export const updateSpinCost = async (req, res, next) => {
  try {
    const { spinCost } = req.body;
    if (useDb) {
      const setting = await Settings.findOneAndUpdate(
        { key: "spin_cost" },
        { value: spinCost },
        { upsert: true, new: true }
      );
      res.json({ spinCost: setting.value });
    } else {
      memory.setSpinCost(spinCost);
      res.json({ spinCost });
    }
  } catch (err) {
    next(err);
  }
};
