import Reward from "../models/Reward.js";
import { memory } from "../services/memoryStore.js";

const useDb = process.env.NO_DB !== "1";

export const listRewards = async (req, res, next) => {
  try {
    const rewards = useDb
      ? await Reward.find({ active: true }).sort({ order: 1 })
      : memory.listRewards();
    res.json({ rewards });
  } catch (err) {
    next(err);
  }
};
