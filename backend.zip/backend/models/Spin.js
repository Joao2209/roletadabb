﻿import mongoose from "mongoose";

const spinSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    rewardId: { type: mongoose.Schema.Types.ObjectId, ref: "Reward", required: true },
    rewardLabel: { type: String, required: true },
    cost: { type: Number, required: true },
    resultAngle: { type: Number, required: true },
    rotationDegrees: { type: Number, required: true },
  },
  { timestamps: true }
);

export default mongoose.model("Spin", spinSchema);
