﻿import mongoose from "mongoose";

const paymentSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    provider: { type: String, default: "syncpay" },
    providerId: { type: String, required: true },
    status: { type: String, enum: ["pending", "confirmed", "failed"], default: "pending" },
    amount: { type: Number, required: true },
    bonus: { type: Number, default: 0 },
    qrCode: { type: String },
    qrCodeText: { type: String },
    raw: { type: Object, default: {} },
  },
  { timestamps: true }
);

export default mongoose.model("Payment", paymentSchema);
