﻿import mongoose from "mongoose";

const rewardSchema = new mongoose.Schema(
  {
    label: { type: String, required: true },
    weight: { type: Number, required: true },
    type: {
      type: String,
      enum: ["free_spin", "content", "access", "cash", "special"],
      default: "content",
    },
    value: { type: Number, default: 0 },
    active: { type: Boolean, default: true },
    order: { type: Number, default: 0 },
    color: { type: String, default: "#f59e0b" }
  },
  { timestamps: true }
);

export default mongoose.model("Reward", rewardSchema);
